# hawaii_coronavirus_bot
Web Scraper for COVID-19 cases in Hawaii that posts results to Twitter or email.
